# OLA AI Runtime Audit - przykład z rzeczywistego CI

Przebieg z 4 listopada 2026, na danych testowych. Brak danych klienta.
Raport: OLA_AI_RUNTIME_AUDIT_SAMPLE_2026-11-04.pdf. Dane strukturalne: report.json.

Potwierdzono sześć wywołań prawdziwego Ollama, wynik narzędzia 391, pełny
łańcuch ośmiu rekordów oraz odtworzenie siedmiu wcześniejszych zdarzeń.
Human Gate: REVIEW. Produkcja: poza zakresem.

## Samodzielna weryfikacja

Wymagany Python 3.10 lub nowszy. Bez pip, Dockera, kluczy API i dostępu do modelu.

Po rozpakowaniu otwórz terminal w katalogu zawierającym verify.py:

```powershell
py -3 verify.py --expected-source 1dd3b0d1b09ca191f91b490e45673ffa95de5b4a --expected-artifact-sha256 43b742e6938ea40a637c876a1f19592da20034a1b52ead611dac6827cc962a68
py -3 test_verify.py
```

Na macOS/Linux zastąp `py -3` przez `python3`.

Oczekiwany wynik: status PASS, records 8, provider_calls 6, result 391,
human_gate REVIEW, production NOT_ASSESSED. Testy: 19/19 PASS, w tym
18 odrzuconych przypadków negatywnych. Kod wyjścia 0 oznacza powodzenie;
BLOCK lub niezerowy kod wyjścia oznacza zatrzymanie weryfikacji.

### Windows - katalog na dysku D

```powershell
Expand-Archive .\OLA_AI_RUNTIME_AUDIT_SAMPLE_2026-11-04.zip -DestinationPath D:\OLA\AuditSample
Set-Location D:\OLA\AuditSample
```

Katalog docelowy powinien być nowy lub pusty.

### Skąd wziąć kotwicę zaufania

Nie traktuj sumy zapisanej w otrzymanym ZIP jako niezależnego dowodu.
Sprawdź SHA źródła i digest artefaktu w GitHub:

- Przebieg: https://github.com/krzysztofcieciwa07-ship-it/OLA/actions/runs/41835035434
- Metadane artefaktu: https://api.github.com/repos/krzysztofcieciwa07-ship-it/OLA/actions/artifacts/13325371050
- Pole `digest`: `sha256:43b742e6938ea40a637c876a1f19592da20034a1b52ead611dac6827cc962a68`
- Pole `workflow_run.head_sha`: `1dd3b0d1b09ca191f91b490e45673ffa95de5b4a`

Metadane/API artefaktów mogą wymagać własnej sesji GitHub. Nie podawaj kluczy
weryfikatorowi. Pobierz oryginalne archiwum z tego przebiegu, jeśli chcesz
porównać je bezpośrednio. Plik `evidence/runtime-original.zip` zachowuje
oryginalne bajty; nic nie zostało w nim zanonimizowane ani przepisane.
Występujące tam identyfikatory są losowymi identyfikatorami jednorazowego
testu, nie identyfikatorami klientów.

`MANIFEST.sha256` wykrywa zmiany plików pakietu, gdy masz zaufaną kopię
manifestu. Sam manifest nie uwierzytelnia nadawcy ani całego środowiska CI.

## Co sprawdza verify.py

- SHA-256 oryginalnego archiwum względem przekazanej kotwicy.
- Powiązanie zmierzonych plików kontenera z drzewem źródeł GitHub.
- Wszystkie rekordy od genesis, kolejność, tenant, run, typ i producenta V2.
- Konteksty sześciu ról i powiązanie promptów z odpowiedziami Ollama.
- Niezależne obliczenie 17 * 23 i zgodność wyniku z dowodami.
- Odtworzenie replay, hash raportu, rekord kandydata i Human Gate REVIEW.

## Granice wniosku

- Przykład pochodzi z gałęzi kandydującej, nie z wdrożenia produkcyjnego.
- Prompt podaje oczekiwany wynik 391; nie jest to benchmark inteligencji.
- Kolejność i narzędzia są zaprogramowane. Wynik liczy kalkulator; tekst modelu nie steruje działaniami.
- Trzy odpowiedzi osiągnęły limit 96 tokenów. Nie oceniono jakości ani kompletności tekstu modelu.
- Human Gate dotyczy zatwierdzenia kandydata po obliczeniu testowym, nie dowodzi bramki przed każdym narzędziem.
- Replay oznacza odtworzenie zapisanych zdarzeń, nie ponowne wnioskowanie LLM.
- Granica zaufania to GitHub CI i rejestrator. Brak atestacji sprzętowej i niezależnego podpisu tożsamości.

## Zawartość

- `report.json`, `report.md`, PDF: opis i granice sprawdzonego przypadku.
- `verify.py`, `test_verify.py`: weryfikator i testy podmian.
- `evidence/runtime-original.zip`: niezmienione archiwum GitHub Actions.
- `evidence/github-provenance.json`: pobrane metadane przebiegu i kroków.
- `evidence/validation-results.json`, `validation.log`: wynik lokalnych sprawdzeń.
- `source/`: odpowiadające źródła i snapshot drzewa plików.
- `offer-snippet.html`: fragment oferty gotowy do dołączenia przy publikacji.

Źródło audytowanego przebiegu: `1dd3b0d1b09ca191f91b490e45673ffa95de5b4a`.
Przykład nie jest certyfikatem zgodności, zgodą na produkcję ani dowodem płatności.
