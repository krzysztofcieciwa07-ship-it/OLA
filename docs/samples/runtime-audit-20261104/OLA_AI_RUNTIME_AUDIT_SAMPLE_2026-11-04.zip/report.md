# OLA AI Runtime Audit - raport przykładowy

**OLA-SAMPLE-20261104-A | 04.11.2026 | dane testowe bez danych klienta**

**VERIFIED**: rzeczywisty przebieg CI i lokalna rekonstrukcja dowodów.
**REVIEW**: zatwierdzenie kandydata przez człowieka. **Produkcja: poza zakresem.**

Zadanie: `Calculate 17 * 23 and return the exact verified result 391.` Wynik narzędzia: **391**.

| Kontrola | Wynik | Materiał |
|---|---|---|
| Wywołania Ollama | 6 zakończonych odpowiedzi | provider-trace.jsonl w oryginalnym archiwum |
| Pełny łańcuch V2 | 8/8 rekordów | evidence-export.json |
| Replay | 7 zdarzeń przed kandydatem | runtime_response.replay |
| Wynik obliczenia | 17 * 23 = 391 | niezależny kalkulator w verify.py |
| Podmiany i błędne kotwice | 18/18 odrzuconych | test_verify.py |
| Human Gate | REVIEW | odpowiedź i rekord decision.candidate |

## Pomiar wywołań modelu

| Rola | Czas żądania (s) | Tokeny odpowiedzi | Zakończenie |
|---|---:|---:|---|
| codeact | 2.004 | 16 | stop |
| react | 4.029 | 42 | stop |
| agentic_rag | 5.787 | 96 | length |
| mcp_tool_use | 6.274 | 96 | length |
| self_reflection | 6.015 | 96 | length |
| multi_agent | 5.178 | 87 | stop |

Suma czasów żądań: 29.287 s. To pomiar tego przebiegu, nie SLO ani wynik p95.
Okno lokalne: 14:07:48 - 14:08:18 Europe/Brussels.

## Granice dowodu

- This is a disposable CI fixture on a candidate branch, not production or a customer audit.
- The prompt contains the expected answer 391. This is not a model intelligence benchmark.
- Tools and order are programmed. The final arithmetic result is calculated by safe_expression; model text does not select actions.
- Three responses reached the 96-token limit (done_reason=length). Semantic correctness and completeness of model output were not assessed.
- Human Gate REVIEW blocks candidate promotion after the controlled computation; this run does not prove approval before all tool execution.
- Replay reconstructs stored events. No second model run or deterministic inference replay is claimed.
- A GitHub CI runner and its recorder are the trust boundary. File hashes are not an external identity, signature or hardware attestation.

Instrukcja i komendy: README.md. Dane strukturalne: report.json.
SHA źródła: `1dd3b0d1b09ca191f91b490e45673ffa95de5b4a`.
SHA-256 oryginalnego artefaktu: `43b742e6938ea40a637c876a1f19592da20034a1b52ead611dac6827cc962a68`.
Źródło: https://github.com/krzysztofcieciwa07-ship-it/OLA/actions/runs/41835035434
