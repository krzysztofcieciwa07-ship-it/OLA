#!/usr/bin/env python3
"""Offline checks for the OLA fixture evidence bundle. Python 3.10+, no dependencies.

Supply the source SHA and archive SHA-256 obtained independently from GitHub.
A PASS verifies this captured CI sample; it is not a production authorization.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

ROLES = ["codeact", "react", "agentic_rag", "mcp_tool_use", "self_reflection", "multi_agent"]
CAPABILITIES = [
    "executed_safe_expression", "reason_act_observe", "retrieved_prior_evidence",
    "invoked_tool", "checked_previous_output", "aggregated_agent_outputs",
]
MODEL = "qwen2.5:0.5b-instruct"
TASK = "Calculate 17 * 23 and return the exact verified result 391."
META = "__ola_evidence_v2__"
MEMBERS = {
    "ollama-models.json", "nina-igor-ollama-proof.json", "ola-nina-ollama-runtime.log",
    "evidence-export.json", "provider-trace.jsonl",
}
PRIVILEGED = ("agent.", "workflow.", "task.", "human.", "provenance.",
              "decision.", "execution.", "verification.")


class Block(ValueError):
    pass


def require(condition, reason):
    if not condition:
        raise Block(reason)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def chain_hash(row):
    payload = json.loads(row["payload_json"])
    meta = payload.get(META)
    require(isinstance(meta, dict) and set(meta) == {"version", "record_type", "producer"},
            "missing or invalid V2 metadata")
    require(type(meta["version"]) is int and meta["version"] == 2, "invalid V2 version")
    require(meta["record_type"] == row["record_type"], "record type binding mismatch")
    require(meta["producer"] in {"ola_runtime", "tenant_api"}, "unknown producer")
    if row["record_type"].startswith(PRIVILEGED):
        require(meta["producer"] == "ola_runtime", "untrusted privileged record")
    return digest(canonical({
        "domain": "OLA-EVIDENCE-CHAIN-V2", "tenant_id": row["tenant_id"],
        "seq": row["seq"], "prev_hash": row["prev_hash"],
        "record_type": row["record_type"], "producer": meta["producer"],
        "payload_json": row["payload_json"],
    }))


def verify_contents(files, expected_source, tree):
    """Pure verification; used by mutation tests after bypassing archive integrity."""
    evidence = json.loads(files["evidence-export.json"])
    proof = json.loads(files["nina-igor-ollama-proof.json"])
    traces = [json.loads(line) for line in files["provider-trace.jsonl"].splitlines() if line.strip()]
    require(evidence["schema"] == "ola.portable-ci-evidence.v1" and
            evidence["fixture_only"] is True, "not a declared disposable CI fixture")
    context = evidence["context"]
    run_id, tenant_id = context["run_id"], context["tenant_id"]
    require(context["task"] == TASK, "unexpected task")
    require(proof["run_id"] == run_id and proof["tenant_id"] == tenant_id,
            "proof/context identity mismatch")
    require(proof["commit"] == expected_source and tree["source_sha"] == expected_source,
            "source mismatch")
    environment = evidence["observed_environment"]
    for name, value in {
        "OLA_RUNTIME_COMMIT": expected_source, "OLA_LLM_PROVIDER": "ollama",
        "OLA_LLM_MODE": "required", "OLA_LLM_MODEL": MODEL,
        "OLLAMA_MODEL": MODEL, "OLA_OLLAMA_NUM_PREDICT": "96",
    }.items():
        require(environment.get(name) == value, "runtime environment mismatch: " + name)
    tree_entries = {entry["path"]: entry["sha"] for entry in tree["entries"]}
    expected_files = {
        path for path in tree_entries if
        (path.startswith("app/") and path.endswith(".py") and path.count("/") == 1)
        or path in {"scripts/verify_agent_runtime.py", "scripts/capture_runtime_sample.py"}
    }
    measured = evidence["runtime_sources"]
    require(set(measured) == expected_files, "incomplete measured runtime source set")
    for path, hashes in measured.items():
        require(hashes["git_blob_sha1"] == tree_entries[path],
                "measured source file differs from GitHub tree: " + path)
        require(re.fullmatch("[0-9a-f]{64}", hashes["sha256"]) is not None,
                "invalid measured SHA-256")
    rows = evidence["records"]
    require(len(rows) == 8, "expected complete 8-record fixture chain including candidate")
    require(len({row["id"] for row in rows}) == len(rows), "duplicate evidence id")
    previous = "0" * 64
    for index, row in enumerate(rows):
        require(row["tenant_id"] == tenant_id, "tenant mismatch")
        require(type(row["seq"]) is int and row["seq"] == index and
                row["prev_hash"] == previous, "sequence or predecessor mismatch")
        require(row["record_hash"] == chain_hash(row), "record hash mismatch")
        previous = row["record_hash"]
    payloads = [json.loads(row["payload_json"]) for row in rows]
    require(all(payload.get("run_id") == run_id for payload in payloads), "run mismatch")
    require([row["record_type"] for row in rows] ==
            ["agent." + role for role in ROLES] + ["provenance.runtime", "decision.candidate"],
            "unexpected role order or chain structure")
    require(len(traces) == 6, "expected exactly six recorded provider calls")
    instances, contexts, response_ids = set(), set(), []
    previous_output, execution = {"task": TASK}, []
    for index, (role, payload, trace) in enumerate(zip(ROLES, payloads[:6], traces)):
        require(payload["agent"] == role and payload["status"] == "VERIFIED" and
                payload["capability"] == CAPABILITIES[index], "agent capability/status mismatch")
        require(payload["task"] == TASK and payload["execution_boundary"] == "independent",
                "agent task or execution metadata mismatch")
        require(payload["llm_required"] is True, "LLM was not required")
        require(payload["provider"] == "ollama" and payload["model"] == MODEL and
                payload["invocation_type"] == "real_llm", "unexpected provider metadata")
        instances.add(payload["agent_instance_id"])
        contexts.add(payload["context_digest"])
        recorded_context = {
            "run_id": run_id, "agent": role, "agent_instance_id": payload["agent_instance_id"],
            "task": TASK, "previous_output": previous_output,
            "upstream_agents": [entry["agent"] for entry in execution],
        }
        require(payload["context_digest"] == digest(canonical(recorded_context)),
                "agent context digest mismatch")
        require(payload["input_digest"] == digest(json.dumps(previous_output, sort_keys=True)),
                "agent input digest mismatch")
        prompt = canonical({"agent": role, "task": TASK, "context": {
            "task": TASK, "previous_output": previous_output,
            "upstream_agents": [entry["agent"] for entry in execution],
        }})
        require(payload["prompt_digest"] == digest(prompt), "prompt digest mismatch")
        require(trace["schema"] == "ola.ci-provider-capture.v1" and
                trace["http_status"] == 200 and trace["upstream"] == "loopback-ollama" and
                trace["method"] == "POST" and trace["path"] == "/api/chat",
                "provider transport mismatch")
        require(trace["duration_seconds"] > 0, "invalid provider duration")
        request, response = trace["request"], trace["response"]
        require(request["model"] == MODEL and request["stream"] is False and
                request["messages"][1]["content"] == prompt, "provider request mismatch")
        require(response["model"] == MODEL and response["done"] is True and
                response["message"]["role"] == "assistant" and
                isinstance(response["message"]["content"], str) and
                bool(response["message"]["content"].strip()) and
                type(response["eval_count"]) is int and response["eval_count"] > 0,
                "missing completed model response")
        expected_id = response.get("id") or "ollama:" + digest(canonical(response))
        require(payload["response_id"] == expected_id, "provider response binding mismatch")
        response_ids.append(expected_id)
        previous_output = {key: value for key, value in payload.items() if key not in {"run_id", META}}
        execution.append(previous_output)
    require(len(instances) == 6 and len(contexts) == 6 and len(set(response_ids)) == 6,
            "agent contexts or response identities are not unique")
    expected_result = str(17 * 23)
    require(payloads[0]["tool_output"] == expected_result and
            payloads[5]["final_result"] == expected_result, "independent arithmetic result mismatch")
    require(payloads[3]["tool_output"] == digest(payloads[2]["tool_output"]),
            "tool SHA-256 result mismatch")
    require(payloads[4]["tool_output"] == "PASS" and
            json.loads(payloads[5]["tool_output"]) == ROLES[:5], "aggregation/reflection mismatch")
    provenance = payloads[6]
    require(provenance["commit"] == expected_source and provenance["task"] == TASK and
            provenance["result"] == expected_result and
            provenance["response_ids"] == response_ids and provenance["llm_invocations"] == 6 and
            provenance["provider"] == "ollama" and provenance["model"] == MODEL and
            provenance["invocation_type"] == "real_llm", "provenance binding mismatch")
    body = evidence["runtime_response"]
    require(body["run_id"] == run_id and body["tip_hash"] == rows[-1]["record_hash"],
            "response does not bind chain tip")
    expected_status = {"RUNTIME": "VERIFIED", "EVIDENCE": "VERIFIED",
                       "REPLAY_INTEGRITY": "VERIFIED", "POLICY": "VERIFIED",
                       "HUMAN_GATE": "REVIEW", "EXECUTION_ALLOWED": "REVIEW"}
    require(body["status"] == "REVIEW" and body["status_fields"] == expected_status and
            body["human_gate"]["status"] == "BLOCK", "human approval was promoted")
    require(proof["status"] == "REVIEW" and proof["status_fields"] == expected_status and
            proof["human_gate_status"] == "BLOCK" and proof["llm_invocations"] == 6,
            "proof status mismatch")
    require(all(body["igor"]["checks"].get(check) is True for check in
                ["chain", "commit", "task", "result", "provider", "model"]), "IGOR checks mismatch")
    require(body["igor"]["status"] == "VERIFIED" and body["nina"]["status"] == "VERIFIED",
            "NINA/IGOR summary mismatch")
    expected_replay = []
    for row, payload in zip(rows[:7], payloads[:7]):
        expected_replay.append({
            "id": row["id"], "tenant_id": row["tenant_id"], "seq": row["seq"],
            "record_type": row["record_type"], "run_id": payload.get("run_id"),
            "input_digest": payload.get("input_digest"), "tool": payload.get("tool"),
            "status": payload.get("status"),
        })
    require(body["replay"] == expected_replay and
            body["replay_verification"]["event_count"] == 7 and
            body["replay_verification"]["tip_hash"] == rows[6]["record_hash"] and
            body["replay_verification"]["status"] == "VERIFIED", "replay reconstruction mismatch")
    report = dict(body["decision_report"])
    report_digest = report.pop("report_sha256")
    require(report_digest == digest(canonical(report)), "decision report digest mismatch")
    require(report["run_id"] == run_id and report["task"] == TASK and
            report["evidence_ids"] == [row["id"] for row in rows[:7]] and
            report["human_review"]["approved"] is False, "decision report bindings mismatch")
    require(report["nina"] == body["nina"] and report["igor"] == body["igor"] and
            report["policy"] == body["policy"] and report["human_gate"] == body["human_gate"],
            "decision report/response mismatch")
    candidate = payloads[7]
    require(candidate["decision_report_sha256"] == report_digest and
            candidate["status_fields"] == expected_status and
            candidate["candidate_status"] == "REVIEW", "candidate binding mismatch")
    return {
        "status": "PASS", "scope": "captured CI fixture evidence",
        "source_sha": expected_source, "records": len(rows), "provider_calls": len(traces),
        "result": expected_result, "human_gate": "REVIEW", "production": "NOT_ASSESSED",
        "checks": ["archive_anchor", "source_correspondence", "complete_v2_chain",
                   "agent_contexts", "provider_response_binding", "arithmetic_result",
                   "replay_reconstruction", "report_and_candidate_binding", "human_gate"],
        "limit": "GitHub CI and its recorder are the trust boundary; no hardware or third-party attestation.",
    }


def load_archive(path, expected_digest):
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected_digest, "archive SHA-256 mismatch")
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)) and set(names) == MEMBERS,
                "unexpected or duplicate archive members")
        require(sum(info.file_size for info in archive.infolist()) < 20_000_000,
                "archive exceeds verification size limit")
        return {name: archive.read(name).decode("utf-8") for name in names}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-source", required=True)
    parser.add_argument("--expected-artifact-sha256", required=True)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    try:
        require(re.fullmatch("[0-9a-f]{40}", args.expected_source), "invalid expected source SHA")
        require(re.fullmatch("[0-9a-f]{64}", args.expected_artifact_sha256),
                "invalid expected artifact SHA-256")
        files = load_archive(args.root / "evidence/runtime-original.zip", args.expected_artifact_sha256)
        tree = json.loads((args.root / "source/runtime-source-tree.json").read_text(encoding="utf-8"))
        result = verify_contents(files, args.expected_source, tree)
        result["artifact_sha256"] = args.expected_artifact_sha256
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0
    except (Block, OSError, ValueError, KeyError, TypeError, IndexError, zipfile.BadZipFile) as exc:
        print(json.dumps({"status": "BLOCK", "reason": str(exc)}, ensure_ascii=False))
        return 1


if __name__ == "__main__":
    sys.exit(main())

