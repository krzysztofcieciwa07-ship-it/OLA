#!/usr/bin/env python3
"""Mutation checks against the actual captured CI artifact. No model calls."""
import copy
import hashlib
import json
from pathlib import Path
import unittest
import verify

ROOT = Path(__file__).resolve().parent
SOURCE = "1dd3b0d1b09ca191f91b490e45673ffa95de5b4a"
ARCHIVE_DIGEST = "43b742e6938ea40a637c876a1f19592da20034a1b52ead611dac6827cc962a68"
FILES = verify.load_archive(ROOT / "evidence/runtime-original.zip", ARCHIVE_DIGEST)
TREE = json.loads((ROOT / "source/runtime-source-tree.json").read_text(encoding="utf-8"))


def edit_evidence(files, operation, rehash=False):
    evidence = json.loads(files["evidence-export.json"])
    operation(evidence)
    if rehash:
        previous = "0" * 64
        for row in evidence["records"]:
            row["prev_hash"] = previous
            row["record_hash"] = verify.chain_hash(row)
            previous = row["record_hash"]
        evidence["runtime_response"]["tip_hash"] = previous
    files["evidence-export.json"] = json.dumps(evidence)


def edit_payload(evidence, index, field, value):
    row = evidence["records"][index]
    payload = json.loads(row["payload_json"])
    payload[field] = value
    row["payload_json"] = verify.canonical(payload)


def edit_trace(files, operation):
    traces = [json.loads(line) for line in files["provider-trace.jsonl"].splitlines()]
    operation(traces)
    files["provider-trace.jsonl"] = "\n".join(json.dumps(trace) for trace in traces) + "\n"


class ActualArtifactTests(unittest.TestCase):
    def test_00_actual_capture_passes(self):
        result = verify.verify_contents(FILES, SOURCE, TREE)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["human_gate"], "REVIEW")

    def test_01_archive_anchor_rejects_wrong_digest(self):
        with self.assertRaises(verify.Block):
            verify.load_archive(ROOT / "evidence/runtime-original.zip", "0" * 64)

    def test_02_wrong_source_rejected(self):
        with self.assertRaises(verify.Block):
            verify.verify_contents(FILES, "0" * 40, TREE)


def assert_mutation(test, operation):
    files = copy.deepcopy(FILES)
    operation(files)
    with test.assertRaises(verify.Block):
        verify.verify_contents(files, SOURCE, TREE)


MUTATIONS = {
    "missing_chain_record": lambda f: edit_evidence(f, lambda e: e["records"].pop(2)),
    "duplicate_record_id": lambda f: edit_evidence(
        f, lambda e: e["records"][1].update(id=e["records"][0]["id"])),
    "foreign_tenant": lambda f: edit_evidence(
        f, lambda e: e["records"][0].update(tenant_id="other-tenant"), True),
    "wrong_task_with_recomputed_chain": lambda f: edit_evidence(
        f, lambda e: edit_payload(e, 0, "task", "Calculate 99 * 99"), True),
    "wrong_result_with_recomputed_chain": lambda f: edit_evidence(
        f, lambda e: edit_payload(e, 5, "final_result", "392"), True),
    "wrong_run_with_recomputed_chain": lambda f: edit_evidence(
        f, lambda e: edit_payload(e, 0, "run_id", "other-run"), True),
    "missing_provider_call": lambda f: edit_trace(f, lambda traces: traces.pop()),
    "reordered_provider_calls": lambda f: edit_trace(f, lambda traces: traces.reverse()),
    "provider_model_substitution": lambda f: edit_trace(
        f, lambda traces: traces[0]["response"].update(model="other-model")),
    "empty_model_inference": lambda f: edit_trace(
        f, lambda traces: traces[0]["response"].update(eval_count=0)),
    "provider_response_tampering": lambda f: edit_trace(
        f, lambda traces: traces[0]["response"]["message"].update(content="replaced response")),
    "missing_replay_event": lambda f: edit_evidence(
        f, lambda e: e["runtime_response"]["replay"].pop()),
    "human_gate_promotion": lambda f: edit_evidence(
        f, lambda e: e["runtime_response"].update(status="VERIFIED")),
    "measured_source_substitution": lambda f: edit_evidence(
        f, lambda e: e["runtime_sources"]["app/agent_runtime.py"].update(git_blob_sha1="0" * 40)),
    "decision_report_tampering": lambda f: edit_evidence(
        f, lambda e: e["runtime_response"]["decision_report"]["human_review"].update(approved=True)),
    "candidate_promotion_with_recomputed_chain": lambda f: edit_evidence(
        f, lambda e: edit_payload(e, 7, "candidate_status", "VERIFIED"), True),
}

for name, operation in MUTATIONS.items():
    def test_method(self, operation=operation):
        assert_mutation(self, operation)
    setattr(ActualArtifactTests, "test_mutation_" + name, test_method)

if __name__ == "__main__":
    unittest.main(verbosity=2)

